<?php

namespace App\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Routing\RouterInterface;

class GetUrl extends Command
{
    private $router;

    protected function __construct(RouterInterface $router)
    {
        parent::__construct();

        $this->router = $router;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $context = $this->router->getContext();
        $context->setHost('example.com');
        $context->setScheme('https');
        $context->setBaseUrl('my/path');

        $url = $this->router->generate('route-name', ['param-name' => 'param-value']);

        $output->writeln($url);
        // ...
    }
}





    // private $rout;

    // public function construct(RouterInterface $rout)
    // {
    //     $this->setName(name:'First Command')
    //         ->setDescription('Gets Url', InputArgument::REQUIRED, 'Enter a valid Url')
    //         ->rout = $rout;
    // }  

    // protected function execute(InputInterface $input, OutputInterface $output)
    // {
    //     $context = $this->rout->getContext();
    //     $context->setHost('example.com');
    //     $context->setScheme('https');
    //     $context->setBaseUrl('my/path');

    //     $url = $this->rout->generate('route-name', ['param-name' => 'param-value']);

    //     $output->writeln(sprintf('Url -> %s', $url));
    // }




// protected function execute(InputInterface $input, OutputInterface $output)
// {

// }

// protected function configure()
// {
//     $this->setDescription('Busca o url')
//         ->addArgument('url', InputArgument::REQUIRED, 'Por favor insere um url');
// }

// protected function execute(InputInterface $input, OutputInterface $output)
// {

//}